<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use Mail;
use Auth;

class UsersController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $users = User::all()->toArray();
        
        return view('users.index', compact('users'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
         return view('users.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $user_info = new User;
            $user_info->fname = $request->get('fname');
            $user_info->lname = $request->get('lname');
            $user_info->email = $request->get('email');
            $user_info->password = bcrypt($request->get('password'));
            $user_info->phone = $request->get('phone');
            $user_info->profile_pic = $request->get('prof_pic_nm');
        $user_info->save();
        return redirect('/users');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $user = User::find($id);
        
        return view('users.edit', compact('user','id'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $user = User::find($id);
            $user->fname = $request->get('fname');
            $user->lname = $request->get('lname');
            $user->email = $request->get('email');
            $user->phone = $request->get('phone');
            $user->profile_pic = $request->get('prof_pic_nm');
        $user->save();
        return redirect('/users');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $user = User::find($id);
        $user->delete();

        return redirect('/users');
    }

    public function ajaxUploadProfPicReg(Request $request)
    {
        $charity_lg = $request->file('prof_pic');
        $logo_nm = "";

        if ($request->hasFile('prof_pic')) 
        {
           $ext = $charity_lg->getClientOriginalExtension();
           $ext_arr = array("jpg","jpeg","png","bmp");
           $ext= strtolower($ext);

           if(in_array($ext, $ext_arr))
           {
                $pre_logo_txt = uniqid();
                $logo_nm =  $pre_logo_txt .".". $ext;
                $charity_lg->move(public_path("/user-prof"), $logo_nm);
                $doc_path = public_path('/user-prof/').$logo_nm;

                $result = 'success';
           }else{
                $result = 'invalid';
           } 
        }

        return $result."|".$logo_nm;
    }

    public function getProfile()
    {
        $user_id = Auth::user()->id;
        $user_info = User::find($user_id);
        return view('users.profile', compact('user_info','user_id'));
    }

    public function updProfile(Request $request)
    {
        $user_id = $request->uid;
        $user_info = User::find($user_id);

        if($user_info)
        {
            $user_info->fname = $request->fname;
                $user_info->lname = $request->lname;
                $user_info->email = $request->email;
                $user_info->phone = $request->phone;
                $user_info->profile_pic = $request->prof_pic;
            $user_info->save();
        
            echo "success";
            exit;
        }else{
            echo "fail";
            exit;
        }
    }
}
