<!-- index.blade.php -->

<?php $__env->startSection('content'); ?>
  <div class="container">
    <table class="table table-striped">
    <thead>
      <tr>
        <th>ID</th>
        <th>Name</th>
        <th>Email</th>
        <th>Phone</th>
        <th>Profile Picture</th>
      </tr>
    </thead>
    <tbody>
      <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($user['id']); ?></td>
            <td><?php echo e($user['fname']); ?> <?php echo e($user['lname']); ?></td>
            <td><?php echo e($user['email']); ?></td>
            <td><?php echo e($user['phone']); ?></td>
            <td>
                <?php if($user['profile_pic']): ?>
                  <img src="<?php echo e(URL::asset('/user-prof/')); ?>/<?php echo e($user['profile_pic']); ?>" height="60px" width="60px">
                <?php else: ?>
                  <img src="<?php echo e(URL::asset('/imgs/default_thumb.png')); ?>" height="60px" width="60px">
                <?php endif; ?>
            </td>
            <td>
                <a href="<?php echo e(action('UsersController@edit', $user['id'])); ?>" class="btn btn-warning">Edit</a>
            </td>
            <td>
              <form action="<?php echo e(action('UsersController@destroy', $user['id'])); ?>" method="post">
                <?php echo e(csrf_field()); ?>

                <input name="_method" type="hidden" value="DELETE">
                <button class="btn btn-danger" type="submit">Delete</button>
              </form>
            </td>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>