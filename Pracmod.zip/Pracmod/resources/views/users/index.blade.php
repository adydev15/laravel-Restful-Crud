<!-- index.blade.php -->
@extends('master')
@section('content')
  <div class="container">
    <table class="table table-striped">
    <thead>
      <tr>
        <th>ID</th>
        <th>Name</th>
        <th>Email</th>
        <th>Phone</th>
        <th>Profile Picture</th>
      </tr>
    </thead>
    <tbody>
      @foreach($users as $user)
        <tr>
            <td>{{$user['id']}}</td>
            <td>{{$user['fname']}} {{$user['lname']}}</td>
            <td>{{$user['email']}}</td>
            <td>{{$user['phone']}}</td>
            <td>
                @if($user['profile_pic'])
                  <img src="{{ URL::asset('/user-prof/') }}/{{$user['profile_pic']}}" height="60px" width="60px">
                @else
                  <img src="{{ URL::asset('/imgs/default_thumb.png') }}" height="60px" width="60px">
                @endif
            </td>
            <td>
                <a href="{{action('UsersController@edit', $user['id'])}}" class="btn btn-warning">Edit</a>
            </td>
            <td>
              <form action="{{action('UsersController@destroy', $user['id'])}}" method="post">
                {{csrf_field()}}
                <input name="_method" type="hidden" value="DELETE">
                <button class="btn btn-danger" type="submit">Delete</button>
              </form>
            </td>
        </tr>
      @endforeach
    </tbody>
  </table>
  </div>
@endsection