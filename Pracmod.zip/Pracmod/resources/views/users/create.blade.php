<!-- create.blade.php -->
<?php
    $path = url("/");
?>
@extends('master')
@section('content')
<div class="container">
  <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Create User</div>

                <div class="panel-body">
                    <form id="create_user_form" name="create_user_form" class="form-horizontal" method="POST" action="{{url('users')}}">
                        {{ csrf_field() }}

                        <div class="form-group">
                            <label for="fname" class="col-md-4 control-label">First Name</label>

                            <div class="col-md-6">
                                <input id="fname" type="text" class="form-control" name="fname" required autofocus>
                                <span id="err_fname" class="help-block" style="color:#8c0e14;"></span>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="lname" class="col-md-4 control-label">Last Name</label>

                            <div class="col-md-6">
                                <input id="lname" type="text" class="form-control" name="lname" required autofocus>
                                <span id="err_lname" class="help-block" style="color:#8c0e14;"></span>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="email" class="col-md-4 control-label">E-Mail Address</label>

                            <div class="col-md-6">
                                <input id="email" type="email" class="form-control" name="email" required>
                                <span id="err_email" class="help-block" style="color:#8c0e14;"></span>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="password" class="col-md-4 control-label">Password</label>

                            <div class="col-md-6">
                                <input id="password" type="password" class="form-control" name="password" required>
                                <span id="err_pass" class="help-block" style="color:#8c0e14;"></span>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="password-confirm" class="col-md-4 control-label">Confirm Password</label>

                            <div class="col-md-6">
                                <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required>
                                <span id="err_cpass" class="help-block" style="color:#8c0e14;"></span>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="phone" class="col-md-4 control-label">Phone</label>

                            <div class="col-md-6">
                                <input id="phone" type="text" class="form-control" name="phone" value="" required maxlength="12">
                                <span id="err_phone" class="help-block" style="color:#8c0e14;"></span>
                            </div>
                        </div>
                        <input id="prof_pic_nm" type="hidden" name="prof_pic_nm" value="">
                    </form>
                    <form id="prof_pic_form" name="prof_pic_form" action="{{ route('uploadProfPicReg') }}" enctype="multipart/form-data" method="post">

                        <div class="form-group{{ $errors->has('prof_pic_nm') ? ' has-error' : '' }}">
                            <label for="prof_pic" class="col-md-4 control-label">Profile Pic</label>

                            <div class="col-md-6">
                                <input id="prof_pic" type="file" class="form-control" name="prof_pic" accept="image/*">
                                  <span id="err_prof_pic" class="help-block" style="color:#8c0e14;"></span>
                            </div>
                            <img src="{{ URL::asset('/imgs/default_thumb.png') }}" alt="img" style="width: 60px;height: 50px;object-fit: contain;border: 1px solid;" id="prof_pic_prv">
                        </div>
                    </form>

                        <div class="form-group">
                            <div class="col-md-6 col-md-offset-4">
                                <button id="create_sub_btn" name="create_sub_btn" type="button" class="btn btn-primary">
                                    Create User
                                </button>
                            </div>
                        </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script type="text/javascript">
    function isValidEmail(email) {
      var regex = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;
      return regex.test(email);
    }
    $(document).ready(function(){
        var mainpath='<?php echo $path; ?>';

        $("#phone").keypress(function (e) {
         if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) {
              return false;
          }
       });
        //Profile Pic Upload
        $("#prof_pic").change(function(){
            if(this.files[0].size > 2*1024*1024)
            {  
              $("#err_prof_pic").text("Only image smaller than 2MB can be uploaded.");
              return false;
            }else{
                $("#err_prof_pic").text('');
            }

            $('#prof_pic_form').ajaxForm({
              //display the uploaded images
              clearForm:'true',
              beforeSend: function (xhr) {
                      var token = $('meta[name="csrf_token"]').attr('content');

                      if(token) {
                            return xhr.setRequestHeader('X-CSRF-TOKEN', token);
                      }
              },
              data:{},
              success:function(result){
                          //alert(result);
                    result = result.split('|');

                    if(result[0] == "success")
                    {
                        $("#prof_pic_nm").val(result[1]);
                        img_path = mainpath+"/user-prof/"+result[1];
                        $("#prof_pic_prv").attr("src",img_path);
                    }else if(result[0] == "invalid")
                    {
                        $("#err_prof_pic").text("Please Upload Valid Image File.We accept  jpg, jpeg, png and bmp.");
                    }
              },
              error:function(e){
              }
            }).submit();
        });

        $("#create_sub_btn").click(function(){
            var fname = $.trim($("#fname").val());
            var lname = $.trim($("#lname").val());
            var email = $.trim($("#email").val());
            var pass = $.trim($("#password").val());
            var cpass = $.trim($("#password-confirm").val());
            var phone = $.trim($("#phone").val());
            var prof_pic = $("#prof_pic_nm").val();

            if(fname == "")
            {
                $("#err_fname").text("Please Enter First Name.")
                $("#fname").focus();
                return false;
            }else{
              $("#err_fname").text("");
            }

            if(lname == "")
            {
                $("#err_lname").text("Please Enter Last Name.")
                $("#lname").focus();
                return false;
            }else{
              $("#err_lname").text("");
            }

            if(email == "")
            {
                $("#err_email").text("Please Enter Email.")
                $("#email").focus();
                return false;
            }else if(email != "")
            {
              if(!isValidEmail(email))
              {
                $("#err_email").text("Please Enter Valid Email Address.");
                $("#email").focus();
                return false;
              }else{
                $("#err_email").text("");
              }
            }

            if(pass == "")
            {
                $("#err_pass").text("Please Enter Password.")
                $("#password").focus();
                return false;
            }else
            {
                $("#err_pass").text("");
            }

            if(cpass == "")
            {
                $("#err_cpass").text("Please Enter Confirm Password.")
                $("#password-confirm").focus();
                return false;
            }else if(cpass != "")
            {
                if(pass != cpass)
                {
                  $("#err_cpass").text("Password & Confirm Password should be same.");
                }else{
                  $("#err_cpass").text("");    
                }  
            }

            if(phone == "")
            {
                $("#err_phone").text("Please Enter Phone no.")
                $("#phone").focus();
                return false;
            }else{
              $("#err_phone").text("");
            }

            if(prof_pic == "")
            {
                $("#err_prof_pic").text("Please Select Profile Picture.")
                return false;
            }else{
              $("#err_prof_pic").text("");
            }

            
            $("#create_user_form").submit();
        });
    });
</script>
@endsection